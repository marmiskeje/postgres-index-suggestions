﻿Web.ViewModels.AnalysisUnusedObjectsViewModel = function () {
    this.isLoading = false;
    this.data = null;
}
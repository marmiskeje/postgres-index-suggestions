﻿Web.ViewModels.AnalysisWorkloadAnalysisDetailViewModel = function () {
    this.isLoading = false;
    this.isLoadingEnv = false;
    this.isValid = false;
    this.workloadAnalysis = null;
    this.selectedIndicesEnvID = -1;
    this.selectedIndicesEnv = null;
    this.data = null;
}
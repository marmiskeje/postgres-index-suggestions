﻿Web.Data.StatsStatementsRequest = function () {
    this.databaseID = null;
    this.filter = new Web.Data.BaseDateTimeFilter();
    this.filter.commandType = 0;
}

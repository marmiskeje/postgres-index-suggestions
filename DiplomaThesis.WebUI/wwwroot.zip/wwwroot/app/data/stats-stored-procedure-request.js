﻿Web.Data.StatsStoredProcedureRequest = function () {
    this.storedProcedureID = null;
    this.filter = new Web.Data.BaseDateTimeFilter();
}

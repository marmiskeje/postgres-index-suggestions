﻿Web.Data.AnalysisWorkloadsRequest = function () {
    this.databaseID = null;
    this.filter = new Web.Data.BaseDateTimeFilter();
}

﻿Web.Data.StatsStatementRequest = function () {
    this.statementID = null;
    this.filter = new Web.Data.BaseDateTimeFilter();
}

﻿Web.Data.DatabaseData = new function () {
    this.id = 0;
    this.name = "";
}
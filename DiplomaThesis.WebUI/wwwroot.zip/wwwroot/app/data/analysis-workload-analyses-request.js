﻿Web.Data.AnalysisWorkloadAnalysesRequest = function () {
    this.databaseID = null;
    this.filter = new Web.Data.BaseDateTimeFilter();
}

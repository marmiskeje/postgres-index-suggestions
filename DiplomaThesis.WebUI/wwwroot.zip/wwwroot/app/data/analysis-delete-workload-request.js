﻿Web.Data.AnalysisDeleteWorkloadRequest = function () {
    this.workloadID = null;
}

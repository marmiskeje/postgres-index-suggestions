﻿Web.Data.AnalysisUnusedObjectsRequest = function () {
    this.databaseID = null;
}

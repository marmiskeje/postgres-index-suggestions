﻿
Web.Data.BaseDateTimeFilter = function () {
    this.dateFrom = null;
    this.dateTo = null;
}
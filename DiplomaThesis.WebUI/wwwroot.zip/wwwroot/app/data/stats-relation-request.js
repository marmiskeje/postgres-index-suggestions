﻿Web.Data.StatsRelationRequest = function () {
    this.relationID = null;
    this.filter = new Web.Data.BaseDateTimeFilter();
}

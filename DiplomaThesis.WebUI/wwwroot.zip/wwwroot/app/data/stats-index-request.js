﻿Web.Data.StatsIndexRequest = function () {
    this.indexID = null;
    this.filter = new Web.Data.BaseDateTimeFilter();
}

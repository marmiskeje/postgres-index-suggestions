﻿Web.Data.StatsOverviewRequest = function () {
    this.databaseID = null;
    this.filter = new Web.Data.BaseDateTimeFilter();
}

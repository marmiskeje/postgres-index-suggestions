﻿Web.Constants.Defaults = function () {

}

Web.Constants.Defaults.DATE_PERIOD_ADD_FROM_DAYS = -7;